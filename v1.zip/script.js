const projects = document.getElementById("hiprojects")
const contact = document.getElementById("hicontact")
const bio = document.getElementById("hibio")





projects.addEventListener('click', function() {
    window.location.href = 'pages/projects.html';
  });

  contact.addEventListener('click', function() {
    window.location.href = 'pages/contact.html';
  });


  bio.addEventListener('click', function() {
    window.location.href = 'pages/bio.html';
  });


  
  
  